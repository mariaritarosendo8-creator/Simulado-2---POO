class Pedido {
    private Cliente cliente;
    private CarrinhoDeCompras carrinho;

    public Pedido(Cliente cliente, CarrinhoDeCompras carrinho) {
        this.cliente = cliente;
        this.carrinho = carrinho;
    }

    public void finalizar(Pagamento pagamento) {
        try {
            // 1. Subtotal = soma dos itens + frete
            double subtotal = carrinho.calcularTotal() + carrinho.calcularFreteTotal(cliente.getEndereco());

            // 2. Desconto VIP caso o cliente seja ClienteVip
            if (cliente instanceof ClienteVip) {
                ClienteVip vip = (ClienteVip) cliente;
                subtotal -= (subtotal * vip.getPercentualDesconto());
            }

            // 3. Processa valor final com a forma de pagamento e exibe comprovante
            double valorFinal = pagamento.calcularValorFinal(subtotal);
            pagamento.exibirComprovante(subtotal);

            // 4. Adiciona pontos de fidelidade (1 ponto a cada R$ 10,00 pagos)
            int pontosGanhos = (int) (valorFinal / 10.0);
            cliente.adicionarPontos(pontosGanhos);
            System.out.println("Pontos acumulados: " + cliente.getPontosFidelidade());

        } catch (PagamentoRecusadoException e) {
            System.out.println("Pagamento recusado: " + e.getMessage());
        } finally {
            // Bloco finally executado garantidamente ao final de todas as tentativas
            System.out.println("Pedido encerrado.");
        }
    }
}