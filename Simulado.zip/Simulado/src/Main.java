public class Main {
    public static void main(String[] args) {
        System.out.println("=== TECHSHOP - DEMONSTRAÇÃO DO SIMULADO ===\n");

        // Criando Cliente VIP
        ClienteVip clienteVip = new ClienteVip("Ana Silva", "111.222.333-44", "ana@email.com", "60000-000", 0.10);
        System.out.println(clienteVip);

        // Criando Produtos dos 3 tipos
        ProdutoFisico teclado = new ProdutoFisico("F01", "Teclado Mecânico", 100.0, 5, 0.8);
        ProdutoDigital ebook = new ProdutoDigital("D01", "E-book Java", 50.0, 999, 12);
        Assinatura streaming = new Assinatura("S01", "Assinatura Dev", 20.0, 999, 6);

        // Instanciando Carrinho e adicionando produtos
        CarrinhoDeCompras carrinho = new CarrinhoDeCompras();
        try {
            carrinho.adicionar(teclado, 1);
            carrinho.adicionar(ebook, 1);
            carrinho.adicionar(streaming, 1);
        } catch (EstoqueInsuficienteException e) {
            System.out.println("Erro ao adicionar item: " + e.getMessage());
        }

        // --- TENTATIVA 1: Pagamento via Pix (Com Sucesso) ---
        System.out.println("\n--- Tentativa 1: Finalizando com Pix ---");
        Pedido pedido1 = new Pedido(clienteVip, carrinho);
        Pagamento pix = new PagamentoPix();
        pedido1.finalizar(pix);

        // --- TENTATIVA 2: Pagamento via Cartão com Limite Baixo (Forçar Recusa) ---
        System.out.println("\n--- Tentativa 2: Finalizando com Cartão (Forçando Recusa) ---");
        Pedido pedido2 = new Pedido(clienteVip, carrinho);
        // Cartão com 6 parcelas e limite de apenas R$ 50.00 (vai estourar o limite)
        Pagamento cartaoComLimiteBaixo = new PagamentoCartao(6, 50.0);
        pedido2.finalizar(cartaoComLimiteBaixo);
    }
}
