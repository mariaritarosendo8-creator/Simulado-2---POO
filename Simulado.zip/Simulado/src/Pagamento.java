public interface Pagamento {
    public double calcularValorFinal(double valorBase);
    
    public String getDescricao();

    public default void exibirComprovante(double valor) {
        System.out.println("Pago via: " + getDescricao() + "\nR$: " + calcularValorFinal(valor));
    }
}

/*

=== QUESTÃO 03 === 
C) 1.
2.  

*/