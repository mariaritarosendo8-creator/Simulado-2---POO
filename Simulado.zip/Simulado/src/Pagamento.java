interface Pagamento {
    double calcularValorFinal(double valor);
    String getDescricao();

    // Método default: possui implementação padrão na própria interface
    default void exibirComprovante(double valor) {
        System.out.println("Pago via " + getDescricao() + ": R$ " + calcularValorFinal(valor));
    }
}

class PagamentoPix implements Pagamento {
    @Override
    public double calcularValorFinal(double valor) {
        return valor * 0.95; // 5% de desconto
    }

    @Override
    public String getDescricao() {
        return "Pix";
    }
}

class PagamentoBoleto implements Pagamento {
    @Override
    public double calcularValorFinal(double valor) {
        return valor; // Sem alteração
    }

    @Override
    public String getDescricao() {
        return "Boleto";
    }
}

class PagamentoCartao implements Pagamento {
    private int parcelas;
    private double limite; // Novo atributo exigido na Questão 5.a.5

    public PagamentoCartao(int parcelas, double limite) {
        this.parcelas = parcelas;
        this.limite = limite;
    }

    @Override
    public double calcularValorFinal(double valor) {
        double valorFinal = valor;
        if (parcelas > 3) {
            valorFinal = valor * 1.08; // 8% de acréscimo
        }
        
        // Disparo de exceção Unchecked se o valor exceder o limite
        if (valorFinal > limite) {
            throw new PagamentoRecusadoException("Pagamento recusado: valor final (R$ " + valorFinal + ") excede o limite disponível (R$ " + limite + ").");
        }
        
        return valorFinal;
    }

    @Override
    public String getDescricao() {
        return "Cartão de Crédito (" + parcelas + "x)";
    }
}

/*

=== QUESTÃO 03 === 
C) 1. Porque a entrega é um comportamento, e não uma identidade.
2. Herança: Uma classe pode implementar múltiplas interfaces, 
mas pode estender apenas uma classe.
Atributos: Interfaces só possuem constantes (public static final).

*/