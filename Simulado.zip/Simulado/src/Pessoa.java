class Pessoa {
    private String nome;
    private String cpf; // Ajustado de int para String para suportar formatação à esquerda
    private String email;

    public Pessoa(String nome, String cpf, String email) {
        this.nome = nome;
        this.cpf = cpf;
        this.email = email;
    }

    public String getNome() { return nome; }
    public String getCpf() { return cpf; }
    public String getEmail() { return email; }

    @Override
    public String toString() {
        return "Nome: " + nome + " | CPF: " + cpf;
    }
}

class Cliente extends Pessoa {
    private String endereco;
    private int pontosFidelidade; // Começa em 0 conforme o enunciado

    public Cliente(String nome, String cpf, String email, String endereco) {
        super(nome, cpf, email); // Uso obrigatório de super() para reutilizar construtor pai
        this.endereco = endereco;
        this.pontosFidelidade = 0;
    }

    public String getEndereco() { return endereco; }
    public int getPontosFidelidade() { return pontosFidelidade; }

    public void adicionarPontos(int pontos) {
        if (pontos > 0) {
            this.pontosFidelidade += pontos;
        }
    }

    @Override
    public String toString() {
        return super.toString() + " | Endereço: " + endereco;
    }
}

class ClienteVip extends Cliente {
    private double percentualDesconto;

    public ClienteVip(String nome, String cpf, String email, String endereco, double percentualDesconto) {
        super(nome, cpf, email, endereco);
        this.percentualDesconto = percentualDesconto;
    }

    public double getPercentualDesconto() { return percentualDesconto; }

    @Override
    public String toString() {
        // Reutiliza o toString() do Cliente usando super.toString() e adiciona a tag VIP
        return super.toString() + " | VIP (" + (int)(percentualDesconto * 100) + "%)";
    }
}

class Funcionario extends Pessoa {
    private String matricula;
    private double salario;

    public Funcionario(String nome, String cpf, String email, String matricula, double salario) {
        super(nome, cpf, email);
        this.matricula = matricula;
        this.salario = salario;
    }

    public String getMatricula() { return matricula; }
    public double getSalario() { return salario; }
}

/* 

== QUESTAO 01 ==

B) Nem o primeiro trecho compila e o segundo, pois o primeiro está como Cliente e logo após do new ele está como ClienteVip. 
 E o segundo está como ClienteVip e logo após do new ele está como Cliente.

*/