public class Pessoa {
    private String nome;
    private int cpf;
    private String email;

    public Pessoa(String nome, int cpf, String email) {
        this.nome = nome;
        this.cpf = cpf;
        this.email = email;
    }

    public String getNome() {
        return nome;
    }

    public int getCpf() {
        return cpf;
    }

    public String getEmail() {
        return email;
    }

    public String toString() {
        return "Pessoa{" +
                "Nome: " + nome + '\'' +
                ", CPF: " + cpf +
                ", Email: " + email + '\'' +
                '}';
    }
}

class Cliente extends Pessoa {
    private String endereco;
    private int[] pontosFidelidade = {0,1,2,3,4,5};

    public int adicionarPontos(int pontos){}

    public Cliente(String nome, int cpf, String email, String endereco) {
        super(nome,cpf,email);
        this.endereco = endereco;
    }

    public String toString() {
        return "Pessoa{" +
                "Nome: " + nome + '\'' +
                ", CPF: " + cpf +
                ", Email: " + email + '\'' +
                ", Endereco: " + endereco + '\'' +               
                '}';
    }
}

class ClienteVip extends Cliente {
    private double percentualDesconto;


    public ClienteVip(String nome, int cpf, String email, String endereco, double percentualDesconto) {
        super(nome,cpf,email,endereco);
        this.percentualDesconto = percentualDesconto;
    }

    public String toString() {
        return "Pessoa{" +
                "Nome: " + nome + '\'' +
                ", CPF: " + cpf +
                ", Email: " + email + '\'' +
                ", Endereco: " + endereco + '\'' +
                ", Percentual de Desconto: " + percentualDesconto + '\'' +               
                '}';
    }
}

class Funcionario extends Pessoa {
    private int matricula;
    private double salario;

    public Funcionario(String nome, int cpf, String email, int matricula, double salario) {
        super(nome, cpf, email);
        this.matricula = matricula;
        this.salario = salario;
    }

    public String toString() {
        return "Pessoa{" +
                "Nome: " + nome + '\'' +
                ", CPF: " + cpf +
                ", Email: " + email + '\'' +
                ", Matricula: " + matricula +
                ", Salario: " + salario +
                '}';
    }
}

/* 

== QUESTAO 01 ==

B) Nem o primeiro trecho compila e o segundo, pois o primeiro está como Cliente e logo após do new ele está como ClienteVip. 
 E o segundo está como ClienteVip e logo após do new ele está como Cliente.

*/