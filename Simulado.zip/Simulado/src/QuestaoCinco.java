package Simulado;

// Exceção Verificada - obriga o tratamento com try-catch ou throws
class EstoqueInsuficienteException extends Exception {
    public EstoqueInsuficienteException(String nomeProduto, int quantidadeDisponivel) {
        super("Estoque insuficiente para " + nomeProduto + ". Disponível: " + quantidadeDisponivel);
    }
}

// Exceção Não Verificada - herda de RuntimeException
class PagamentoRecusadoException extends RuntimeException {
    public PagamentoRecusadoException(String mensagem) {
        super(mensagem);
    }
}

/*
=== QUESTAO 05 ===
B) A saída do código é:
B: Estoque insuficiente para Teclado. Disponível: 3
C
D

C) EstoqueInsuficienteException estende Exception
(Checked Exception). PagamentoRecusadoException estende
RuntimeException (Unchecked Exception).


*/