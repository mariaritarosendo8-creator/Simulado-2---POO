import java.util.ArrayList;
import java.util.List;

class CarrinhoDeCompras {
    private List<Produto> itens = new ArrayList<>();

    // Sobrecarga de método 1: adiciona 1 unidade
    public void adicionar(Produto p) throws EstoqueInsuficienteException {
        adicionar(p, 1);
    }

    // Sobrecarga de método 2: adiciona quantidade específica e verifica estoque
    public void adicionar(Produto p, int quantidade) throws EstoqueInsuficienteException {
        if (quantidade > p.getEstoque()) {
            throw new EstoqueInsuficienteException(p.getNome(), p.getEstoque());
        }
        for (int i = 0; i < quantidade; i++) {
            itens.add(p);
        }
    }

    // Calcula o total polimorficamente invocando calcularPrecoFinal de cada subclasse
    public double calcularTotal() {
        double total = 0;
        for (Produto p : itens) {
            total += p.calcularPrecoFinal();
        }
        return total;
    }

    // Filtra e soma o frete apenas de objetos que implementam a interface Entregavel
    public double calcularFreteTotal(String cep) {
        double totalFrete = 0;
        for (Produto p : itens) {
            if (p instanceof Entregavel) {
                totalFrete += ((Entregavel) p).calcularFrete(cep);
            }
        }
        return totalFrete;
    }
}

/*

=== QUESTAO 04 ===
B) A saída do código é:
 - Teclado: 110.0
 - E-book Java: 47.5
 - Streaming: 108.0
Chamado de Polimorfismo por Sobrescrita ou Ligação Dinâmica

C) Ela não compila. A referência p1 é do tipo Produto, e a classe 
Produto não possui o método calcularFrete().


*/