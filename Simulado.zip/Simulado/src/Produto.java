abstract class Produto {
    private int codigo;
    private String nome;
    private double precoBase;
    private int estoque;

    public Produto(int codigo, String nome, double precoBase, int estoque) {
        this.codigo = codigo;
        this.nome = nome;
        this.precoBase = precoBase;
        this.estoque = estoque;
    }

    public abstract double calcularPrecoFinal();
    
    public String exibirResumo() {
        return "Codigo: " + codigo + "\nNome: " + nome + "R$: " + precoFinal();
    }

    public void baixarEstoque(int quantidade);
}

class ProdutoFisico extends Produto {
    private double pesoKg;

    public ProdutoFisico(int codigo, String nome, double precoBase, int estoque, double pesoKg) {
        super(codigo, nome, precoBase, estoque);
        this.pesoKg = pesoKg;
    }

    @Override
    public double calcularPrecoFinal() {
        return getPrecoBase() + (pesoKg * 10);
    }
}

class ProdutoDigital extends Produto {
    private double tamanhoMB;

    public ProdutoDigital(int codigo, String nome, double precoBase, int estoque, double tamanhoMB) {
        super(codigo, nome, precoBase, estoque);
        this.tamanhoMB = tamanhoMB;
    }

    @Override
    public double calcularPrecoFinal() {
        return getPrecoBase() + (tamanhoMB * 0.05);
    }
}

class Assinatura extends Produto {
    private int meses;

    public Assinatura(int codigo, String nome, double precoBase, int estoque, int meses) {
        super(codigo, nome, precoBase, estoque);
        this.meses = meses;
    }

    @Override
    public double calcularPrecoFinal() {
        if(meses >= 6){
            return getPrecoBase() * meses * 0.1;
        }
        return getPrecoBase() * meses;
    }
}

/*

=== QUESTAO 02 ===

B) 1.
2.

*/