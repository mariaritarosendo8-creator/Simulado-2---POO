// Interface que define o comportamento de itens físicos entregáveis
interface Entregavel {
    double calcularFrete(String cep);
    int prazoEntregaDias();
}

// Classe abstrata Produto: modelo base que não pode ser instanciado diretamente
abstract class Produto {
    private String codigo;
    private String nome;
    private double precoBase;
    private int estoque;

    public Produto(String codigo, String nome, double precoBase, int estoque) {
        // Validação de preço negativo solicitada na Questão 5.a.4
        if (precoBase < 0) {
            throw new IllegalArgumentException("O preço base não pode ser negativo.");
        }
        this.codigo = codigo;
        this.nome = nome;
        this.precoBase = precoBase;
        this.estoque = estoque;
    }

    public String getCodigo() { return codigo; }
    public String getNome() { return nome; }
    public double getPrecoBase() { return precoBase; }
    public int getEstoque() { return estoque; }

    // Método abstrato: obriga todas as subclasses a implementarem sua regra de preço
    public abstract double calcularPrecoFinal();

    public String exibirResumo() {
        return codigo + " " + nome + ": R$ " + calcularPrecoFinal();
    }

    public void baixarEstoque(int quantidade) {
        if (quantidade <= this.estoque) {
            this.estoque -= quantidade;
        }
    }
}

class ProdutoFisico extends Produto implements Entregavel {
    private double pesoKg;

    public ProdutoFisico(String codigo, String nome, double precoBase, int estoque, double pesoKg) {
        super(codigo, nome, precoBase, estoque);
        this.pesoKg = pesoKg;
    }

    @Override
    public double calcularPrecoFinal() {
        return getPrecoBase() * 1.10; // 10% de imposto
    }

    // Implementação dos métodos da interface Entregavel
    @Override
    public double calcularFrete(String cep) {
        return 15.00 + (2.00 * pesoKg);
    }

    @Override
    public int prazoEntregaDias() {
        return 7; // Simplificado para fins de exemplo
    }
}

class ProdutoDigital extends Produto {
    private int tamanhoMB;

    public ProdutoDigital(String codigo, String nome, double precoBase, int estoque, int tamanhoMB) {
        super(codigo, nome, precoBase, estoque);
        this.tamanhoMB = tamanhoMB;
    }

    @Override
    public double calcularPrecoFinal() {
        return getPrecoBase() * 0.95; // 5% de desconto
    }
}

class Assinatura extends Produto {
    private int meses;

    public Assinatura(String codigo, String nome, double precoBase, int estoque, int meses) {
        super(codigo, nome, precoBase, estoque);
        this.meses = meses;
    }

    @Override
    public double calcularPrecoFinal() {
        double total = getPrecoBase() * meses;
        if (meses >= 6) {
            return total * 0.90; // 10% de desconto para 6 meses ou mais
        }
        return total;
    }
}

/*

=== QUESTAO 02 ===

B) 1. Classes abstratas servem como modelos incompletos e não podem ser instanciadas diretamente.
2. Graças à ligação dinâmica (dynamic binding). Como calcularPrecoFinal() é um método abstrato em Produto

*/
