public interface Entregavel {
    double calcularFrete(String cep);
    int prazoEntregaDias();
}

class ProdutoFisico implements Entregavel {
    private double pesoKg;

    public ProdutoFisico(double pesoKg) {
        this.pesoKg = pesoKg;
    }

    @Override
    public double calcularFrete(String cep) {
        // Implementação do cálculo de frete com base no CEP e peso
        return pesoKg * 5; // Exemplo simplificado
    }

    @Override
    public int prazoEntregaDias() {
        // Implementação do cálculo do prazo de entrega
        return 5; // Exemplo simplificado
    }
}